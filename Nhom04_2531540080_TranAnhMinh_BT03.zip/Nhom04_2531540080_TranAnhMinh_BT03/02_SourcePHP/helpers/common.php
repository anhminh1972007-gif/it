<?php
// helpers/common.php — các hàm tiện ích dùng ở nhiều trang

// e(): chống XSS — đổi ký tự đặc biệt (< > " ') thành dạng hiển thị an toàn
function e($value)
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

// money(15990000) → "15.990.000 đ"
function money($value)
{
    return number_format((float) $value, 0, ',', '.') . ' đ';
}

// redirect(): chuyển trang rồi DỪNG chương trình
function redirect($location)
{
    header('Location: ' . $location);
    exit;
}

// Giá bán thực tế: có giá khuyến mãi thì dùng, không thì dùng giá gốc
function product_price($product)
{
    if (!empty($product['sale_price']) && (float) $product['sale_price'] > 0) {
        return (float) $product['sale_price'];
    }
    return (float) ($product['price'] ?? $product['selling_price'] ?? 0);
}

// Đường dẫn ảnh sản phẩm; không có file ảnh thì dùng ảnh mặc định
function product_image($thumbnail)
{
    $placeholder = asset('customer/images/tech/placeholder-tech.jpg');
    if (empty($thumbnail)) {
        return $placeholder;
    }

    $clean = ltrim($thumbnail, '/');
    if (strpos($clean, 'assets/') === 0) {
        $rel = substr($clean, 7);
        if (is_file(__DIR__ . '/../assets/' . $rel)) {
            return asset($rel);
        }
    }

    $fileName = basename($clean);
    if (is_file(__DIR__ . '/../assets/images/' . $fileName)) {
        return asset('images/' . $fileName);
    }
    if (is_file(__DIR__ . '/../assets/customer/images/tech/' . $fileName)) {
        return asset('customer/images/tech/' . $fileName);
    }

    return is_file(__DIR__ . '/../' . $clean) ? base_url($clean) : $placeholder;
}
