<?php
// helpers/router.php — các hàm URL chung cho cả Public và Admin.

function app_config()
{
    static $config = null;
    if ($config === null) {
        $config = require __DIR__ . '/../config/app.php';
    }
    return $config;
}

function base_url($path = '')
{
    $base = rtrim(app_config()['base_url'], '/');
    // Tự động nhận diện nếu chạy PHP CLI Server hoặc chạy ở Root URL
    if (php_sapi_name() === 'cli-server' || (!empty($_SERVER['REQUEST_URI']) && strpos($_SERVER['REQUEST_URI'], '/minh-store') === false)) {
        $base = '';
    }
    $cleanPath = ltrim($path, '/');
    return ($base === '' ? '' : $base) . ($cleanPath === '' ? '' : '/' . $cleanPath);
}

function url($page = 'home', $params = array())
{
    $query = http_build_query(array_merge(array('page' => $page), $params));
    return base_url('index.php' . ($query ? '?' . $query : ''));
}

function admin_url($page = 'dashboard', $params = array())
{
    $query = http_build_query(array_merge(array('page' => $page), $params));
    return base_url('admin/index.php' . ($query ? '?' . $query : ''));
}

function asset($path)
{
    return base_url('assets/' . ltrim($path, '/'));
}

function get_param($name, $default = '')
{
    if (!isset($_GET[$name]) || !is_string($_GET[$name])) {
        return $default;
    }
    return trim($_GET[$name]);
}
