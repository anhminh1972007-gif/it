<?php
// classes/Database.php — class làm việc với MySQL bằng MySQLi
// Các trang KHÔNG gọi mysqli trực tiếp mà gọi qua class này.

class Database
{
    // Thuộc tính giữ kết nối; private = chỉ dùng bên trong class
    private $connection;

    // Hàm khởi tạo: tự chạy khi viết new Database($config)
    public function __construct($config)
    {
        // Mở kết nối tới MySQL (lỗi sẽ ném exception, PHP 8.1+)
        $this->connection = new mysqli(
            $config['host'],
            $config['username'],
            $config['password'],
            $config['database'],
            $config['port']
        );

        // Đặt bảng mã để đọc/ghi tiếng Việt đúng
        $this->connection->set_charset($config['charset']);
    }

    // Chạy câu SQL có dấu ? và trả về đối tượng statement đã thực thi
    // $params: mảng giá trị lần lượt thay cho từng dấu ?
    private function run($sql, $params)
    {
        $statement = $this->connection->prepare($sql);  // 1. gửi khuôn SQL có chỗ trống ?
        $statement->execute($params);                   // 2. gắn giá trị vào ? rồi chạy
        return $statement;
    }

    // Lấy NHIỀU dòng → mảng hai chiều (mỗi phần tử là một dòng)
    public function fetchAll($sql, $params = array())
    {
        $result = $this->run($sql, $params)->get_result();  // gói kết quả
        return $result->fetch_all(MYSQLI_ASSOC);            // khóa của mảng = tên cột
    }

    // Lấy MỘT dòng → mảng một chiều, không có thì trả về null
    public function fetchOne($sql, $params = array())
    {
        $result = $this->run($sql, $params)->get_result();
        $row = $result->fetch_assoc();                       // dòng đầu tiên hoặc null

        return $row ?: null;
    }

    // Chạy INSERT / UPDATE / DELETE → trả về số dòng bị thay đổi
    public function execute($sql, $params = array())
    {
        return $this->run($sql, $params)->affected_rows;
    }

    // Lấy id tự tăng vừa được tạo bởi câu INSERT gần nhất
    public function insertId()
    {
        return $this->connection->insert_id;
    }
}
