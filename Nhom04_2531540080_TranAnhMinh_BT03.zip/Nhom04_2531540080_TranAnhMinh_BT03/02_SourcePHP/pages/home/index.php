<!-- pages/home/index.php — Trang chủ chuẩn giao diện CellphoneS Minh Store -->

<!-- Section 1: Hero Banner & Sidebar Danh Mục -->
<section class="hero-section">
    <div class="container hero-container">

        <!-- Sidebar Danh mục bên trái -->
        <aside class="cat-sidebar">
            <div class="cat-sidebar-header">
                📂 Danh Mục Đồ Gia Dụng
            </div>
            <ul>
                <li><a href="<?= e(url('products', array('category' => 'KITCHEN'))) ?>"><span>🍳</span> Nồi Chiên Không Dầu</a></li>
                <li><a href="<?= e(url('products', array('category' => 'CLEANING'))) ?>"><span>🤖</span> Robot Hút Bụi & Lau Nhà</a></li>
                <li><a href="<?= e(url('products', array('category' => 'AIR_WATER'))) ?>"><span>🍃</span> Máy Lọc Không Khí</a></li>
                <li><a href="<?= e(url('products', array('category' => 'KITCHEN'))) ?>"><span>⚡</span> Bếp Từ Đôi Inverter</a></li>
                <li><a href="<?= e(url('products', array('category' => 'KITCHEN'))) ?>"><span>🍚</span> Nồi Cơm Điện Cao Tần</a></li>
                <li><a href="<?= e(url('products', array('category' => 'KITCHEN'))) ?>"><span>🍎</span> Máy Ép Chậm Trái Cây</a></li>
                <li><a href="<?= e(url('products', array('category' => 'AIR_WATER'))) ?>"><span>💧</span> Máy Lọc Nước Hydrogen</a></li>
                <li><a href="<?= e(url('products', array('category' => 'UTENSILS'))) ?>"><span>🥘</span> Bộ Nồi Chảo Inox 304</a></li>
                <li><a href="<?= e(url('products', array('category' => 'SMART_HOME'))) ?>"><span>🔐</span> Khóa Cửa Điện Tử Face ID</a></li>
            </ul>
        </aside>

        <!-- Banner chính giữa -->
        <div class="hero-banner">
            <div class="hero-banner-inner">
                <div>
                    <span class="banner-badge">🔥 ĐẠI TIỆC GIA DỤNG MÙA THU</span>
                    <h1 class="banner-title">Nâng Tầm Tiện Nghi Gian Bếp Hiện Đại</h1>
                    <p class="banner-desc">
                        Săn deal đồ gia dụng thông minh chính hãng giảm tới 45%. Hàng mới 100% nguyên seal, bảo hành tại nhà 24 tháng.
                    </p>
                    <div class="banner-perks">
                        <span>✓ Đổi mới 30 ngày</span>
                        <span>✓ Giao nhanh 2H</span>
                        <span>✓ Trả góp 0%</span>
                    </div>
                    <div style="display: flex; gap: 10px; flex-wrap: wrap;">
                        <a href="<?= e(url('products')) ?>" style="display: inline-flex; align-items: center; gap: 6px; background: #ffffff; color: #d70018; padding: 10px 20px; border-radius: 9999px; font-weight: 800; font-size: 13px; text-decoration: none; box-shadow: 0 4px 12px rgba(0,0,0,0.15);">
                            🛍️ Mua Ngay Giá Tốt
                        </a>
                        <a href="<?= e(admin_url('dashboard')) ?>" style="display: inline-flex; align-items: center; gap: 6px; background: rgba(255,255,255,0.2); color: #ffffff; border: 1px solid rgba(255,255,255,0.4); padding: 10px 18px; border-radius: 9999px; font-weight: 700; font-size: 13px; text-decoration: none;">
                            ⚙️ Quản Trị (Mô Phỏng)
                        </a>
                    </div>
                </div>

                <div style="text-align: center;">
                    <img src="<?= e(asset('images/hero_showcase.jpg')) ?>" alt="Đồ gia dụng Minh Store" class="hero-main-img" onerror="this.onerror=null; this.src='<?= e(asset('images/air_fryer.jpg')) ?>';">
                </div>
            </div>
        </div>

        <!-- Banners deal hot bên phải -->
        <div class="hero-side-banners">
            <a href="<?= e(url('product-detail', array('id' => 2))) ?>" class="side-promo-card">
                <div>
                    <span style="font-size: 10.5px; font-weight: 800; color: #d70018; background: #fee2e2; padding: 2px 6px; border-radius: 4px;">HOT DEAL</span>
                    <div style="font-size: 13px; font-weight: 800; color: #1e293b; margin: 4px 0 2px 0;">Robot Deebot T20</div>
                    <div style="font-size: 12px; font-weight: 700; color: #d70018;">11.490.000đ</div>
                    <span style="font-size: 11px; color: #2563eb;">Giặt sấy tự động 55°C &rarr;</span>
                </div>
                <div class="side-promo-thumb">
                    <img src="<?= e(asset('images/robot_vacuum.jpg')) ?>" alt="Robot hút bụi Ecovacs" onerror="this.onerror=null; this.src='<?= e(asset('images/air_fryer.jpg')) ?>';">
                </div>
            </a>

            <a href="<?= e(url('product-detail', array('id' => 1))) ?>" class="side-promo-card">
                <div>
                    <span style="font-size: 10.5px; font-weight: 800; color: #d70018; background: #fee2e2; padding: 2px 6px; border-radius: 4px;">GIẢM 25%</span>
                    <div style="font-size: 13px; font-weight: 800; color: #1e293b; margin: 4px 0 2px 0;">Nồi Chiên XXL 7.2L</div>
                    <div style="font-size: 12px; font-weight: 700; color: #d70018;">2.890.000đ</div>
                    <span style="font-size: 11px; color: #2563eb;">Công nghệ Rapid Air &rarr;</span>
                </div>
                <div class="side-promo-thumb">
                    <img src="<?= e(asset('images/air_fryer.jpg')) ?>" alt="Nồi chiên Philips" onerror="this.onerror=null; this.src='<?= e(asset('images/air_fryer.jpg')) ?>';">
                </div>
            </a>
        </div>

    </div>
</section>

<!-- Section 2: Cam kết dịch vụ Minh Store -->
<section class="commitments-bar">
    <div class="container">
        <div class="commitments-grid">
            <div class="commit-box">
                <span class="icon">🛡️</span>
                <div class="text">
                    <strong>100% Chính Hãng</strong>
                    <span>Nguyên seal, đầy đủ hóa đơn VAT</span>
                </div>
            </div>
            <div class="commit-box">
                <span class="icon">🚚</span>
                <div class="text">
                    <strong>Miễn Phí Giao Hàng</strong>
                    <span>Đơn từ 300K, giao nhanh 2H nội thành</span>
                </div>
            </div>
            <div class="commit-box">
                <span class="icon">🔄</span>
                <div class="text">
                    <strong>1 Đổi 1 Trong 30 Ngày</strong>
                    <span>Bảo hành chính hãng 24 tháng toàn quốc</span>
                </div>
            </div>
            <div class="commit-box">
                <span class="icon">💳</span>
                <div class="text">
                    <strong>Trả Góp 0% Lãi Suất</strong>
                    <span>Hỗ trợ thẻ tín dụng và CCCD tiện lợi</span>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- Section 3: Danh mục sản phẩm nổi bật -->
<section class="catalog-section" id="catalog" style="padding-top: 24px; padding-bottom: 36px;">
    <div class="container">

        <div class="catalog-header-bar">
            <div class="catalog-title">
                <span>🔥</span>
                <span>Thiết Bị Đồ Gia Dụng Nổi Bật Mới Nhất</span>
                <span style="font-size: 13px; font-weight: 600; color: #64748b;">(<?= count($products) ?> sản phẩm)</span>
            </div>

            <div class="catalog-filter-tabs">
                <a href="<?= e(url('products')) ?>" class="filter-tab active">Tất Cả</a>
                <a href="<?= e(url('products', array('category' => 'KITCHEN'))) ?>" class="filter-tab">🍳 Thiết Bị Bếp</a>
                <a href="<?= e(url('products', array('category' => 'CLEANING'))) ?>" class="filter-tab">🤖 Robot & Hút Bụi</a>
                <a href="<?= e(url('products', array('category' => 'AIR_WATER'))) ?>" class="filter-tab">🍃 Lọc Khí & Nước</a>
                <a href="<?= e(url('products', array('category' => 'UTENSILS'))) ?>" class="filter-tab">🥘 Nồi Chảo Inox</a>
                <a href="<?= e(url('products', array('category' => 'SMART_HOME'))) ?>" class="filter-tab">🔐 Khóa & Smart Home</a>
            </div>
        </div>

        <div style="background: #fff; border-radius: 8px; border: 1px solid #e5e7eb; padding: 12px 18px; margin-bottom: 20px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 10px;">
            <div style="font-size: 13px; color: #475569;">
                ✨ Sản phẩm được truy vấn trực tiếp từ <strong>CSDL MySQL (minh_store_db)</strong> qua <strong>Class Database (MySQLi)</strong>
            </div>
            <a href="<?= e(url('products')) ?>" style="font-size: 13px; font-weight: 800; color: #d70018; text-decoration: none;">
                Xem toàn bộ <?= count($allProducts) ?> sản phẩm gia dụng →
            </a>
        </div>

        <!-- Lưới sản phẩm đồ gia dụng -->
        <div class="products-grid">
            <?php foreach ($products as $product): ?>
                <?php require __DIR__ . '/../../layouts/public/product-card.php'; ?>
            <?php endforeach; ?>
        </div>

        <div style="text-align: center; margin-top: 28px;">
            <a href="<?= e(url('products')) ?>" style="display: inline-flex; align-items: center; gap: 8px; background: #d70018; color: #ffffff; font-weight: 800; font-size: 14px; padding: 12px 28px; border-radius: 8px; text-decoration: none; box-shadow: 0 4px 12px rgba(215,0,24,0.25);">
                Xem Tất Cả Sản Phẩm Gia Dụng (<?= count($allProducts) ?> sản phẩm) →
            </a>
        </div>

    </div>
</section>
