<?php
// pages/home/action.php — chuẩn bị dữ liệu cho trang chủ (chưa in HTML)
require_once __DIR__ . '/../products/functions.php';

$title = 'Trang chủ mua sắm đồ gia dụng';
$allProducts = products_get_all();
$products = array_slice($allProducts, 0, 8); // Lấy 8 sản phẩm mới nhất
