<?php
// pages/404/action.php — chuẩn bị dữ liệu cho trang lỗi 404 (Không tìm thấy trang)
$title = 'Không tìm thấy trang yêu cầu (404)';
