<main class="container py-5 text-center">
    <div class="py-5">
        <h1 class="display-1 fw-bold text-danger">404</h1>
        <h2 class="h4 mb-3">Không tìm thấy trang yêu cầu</h2>
        <p class="text-muted mb-4">Trang bạn đang tìm kiếm không tồn tại hoặc đã được chuyển hướng.</p>
        <a href="<?= e(url('home')) ?>" class="btn btn-primary px-4"><i class="bi bi-house"></i> Về trang chủ</a>
        <a href="<?= e(url('products')) ?>" class="btn btn-outline-secondary px-4 ms-2"><i class="bi bi-grid"></i> Danh mục sản phẩm</a>
    </div>
</main>
