<?php
// pages/student-public/action.php — Trang minh chứng BT03 của sinh viên
require_once __DIR__ . '/../products/functions.php';

$title = 'Trang thực hành cá nhân BT03 - Trần Anh Minh';
$totalProducts = count(products_get_all());
$categories = db()->fetchAll("SELECT c.category_id, c.category_name, COUNT(p.product_id) AS total_items
                             FROM categories c
                             LEFT JOIN products p ON c.category_id = p.category_id AND p.status = 1
                             GROUP BY c.category_id, c.category_name");
