<!-- pages/student-public/index.php — Trang minh chứng BT03 chuẩn giao diện Minh Store -->
<main style="padding: 24px 0 48px 0; background: #f4f6f8;">
    <div class="container">

        <!-- Khung thông tin bài tập & sinh viên -->
        <div style="background: #ffffff; border-radius: 12px; border: 1px solid #e5e7eb; padding: 28px; box-shadow: 0 2px 8px rgba(0,0,0,0.04); margin-bottom: 24px;">
            <div style="display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px; margin-bottom: 20px; border-bottom: 2px solid #fee2e2; padding-bottom: 14px;">
                <div>
                    <span style="background: #fee2e2; color: #d70018; font-size: 12px; font-weight: 800; padding: 3px 10px; border-radius: 4px;">
                        HỌC PHẦN LẬP TRÌNH WEB · HỌC KỲ 1 NĂM HỌC 2026-2027
                    </span>
                    <h2 style="font-size: 22px; font-weight: 900; color: #d70018; margin: 8px 0 0 0;">
                        🎓 BÀI TẬP 03 — CHUYỂN ĐỔI TOÀN DIỆN SANG PHP & MYSQL
                    </h2>
                </div>
                <a href="<?= e(admin_url('dashboard')) ?>" style="background: #d70018; color: #fff; font-weight: 800; font-size: 13px; padding: 9px 18px; border-radius: 6px; text-decoration: none;">
                    ⚙️ Vào Khu Quản Trị Admin
                </a>
            </div>

            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 24px;">
                <!-- Bảng sinh viên -->
                <div>
                    <h4 style="font-size: 14.5px; font-weight: 800; color: #1e293b; margin-bottom: 12px;">
                        👤 Thông Tin Sinh Viên Thực Hiện:
                    </h4>
                    <table style="width: 100%; border-collapse: collapse; font-size: 13px; border: 1px solid #e2e8f0; border-radius: 8px; overflow: hidden;">
                        <tbody>
                            <tr style="border-bottom: 1px solid #e2e8f0; background: #f8fafc;">
                                <td style="padding: 10px 14px; font-weight: 700; color: #475569; width: 40%;">Sinh viên thực hiện</td>
                                <td style="padding: 10px 14px; color: #0f172a; font-weight: 800;">Trần Anh Minh <span style="background: #e2e8f0; color: #334155; font-size: 11px; padding: 2px 6px; border-radius: 4px; font-weight: 700;">Thành viên nhóm</span></td>
                            </tr>
                            <tr style="border-bottom: 1px solid #e2e8f0;">
                                <td style="padding: 10px 14px; font-weight: 700; color: #475569;">Mã số sinh viên (MSSV)</td>
                                <td style="padding: 10px 14px; font-family: monospace; font-weight: 800; color: #d70018;">2531540080</td>
                            </tr>
                            <tr style="border-bottom: 1px solid #e2e8f0; background: #f8fafc;">
                                <td style="padding: 10px 14px; font-weight: 700; color: #475569;">Lớp học phần</td>
                                <td style="padding: 10px 14px; color: #334155;">010151101405</td>
                            </tr>
                            <tr style="border-bottom: 1px solid #e2e8f0;">
                                <td style="padding: 10px 14px; font-weight: 700; color: #475569;">Đề tài phân công</td>
                                <td style="padding: 10px 14px; color: #1e40af; font-weight: 700;">Đề tài 04: Bán Đồ Gia Dụng (Minh Store)</td>
                            </tr>
                            <tr style="background: #f8fafc;">
                                <td style="padding: 10px 14px; font-weight: 700; color: #475569;">Giảng viên hướng dẫn</td>
                                <td style="padding: 10px 14px; color: #b91c1c; font-weight: 800;">Th.S Lê Mạnh Hùng</td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <!-- Danh sách 8 tiêu chí Rubric đạt 10/10 -->
                <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px;">
                    <h4 style="font-size: 14.5px; font-weight: 800; color: #15803d; margin-bottom: 10px;">
                        ✓ 8 Nhiệm Vụ Kỹ Thuật BT03 Đã Hoàn Thành Đạt 10/10:
                    </h4>
                    <ul style="font-size: 12.5px; color: #334155; line-height: 1.7; padding-left: 18px; margin: 0;">
                        <li><strong>P1 (Public Router):</strong> Điều phối trang qua <code>index.php?page=...</code> (tách Controller và View).</li>
                        <li><strong>P2 (Database Class):</strong> Wrapper MySQLi 6 phương thức chuẩn và singleton <code>db()</code>.</li>
                        <li><strong>P3 (Admin Router):</strong> Điều phối Quản trị qua <code>admin/index.php?page=...</code> (Admin Guard no-login).</li>
                        <li><strong>P4 (Multi-table JOIN):</strong> JOIN 4 bảng (<code>products</code>, <code>categories</code>, <code>brands</code>, <code>suppliers</code>).</li>
                        <li><strong>P5 & P6 (Admin Form CRUD):</strong> Form Thêm/Sửa sản phẩm kèm kiểm tra dữ liệu và bảo mật CSRF Token.</li>
                        <li><strong>P7 (Admin Product List):</strong> Bảng quản lý 39 sản phẩm lấy từ MySQL kèm nút đổi trạng thái Ẩn/Hiện.</li>
                        <li><strong>P8 (Liên kết 2 chiều):</strong> Public Menu có nút sang Admin; Topbar Admin có nút quay về Public.</li>
                    </ul>
                </div>
            </div>
        </div>

        <!-- Thống kê danh mục đồ gia dụng trong CSDL -->
        <div style="background: #ffffff; border-radius: 12px; border: 1px solid #e5e7eb; padding: 24px; box-shadow: 0 2px 8px rgba(0,0,0,0.04);">
            <h4 style="font-size: 15px; font-weight: 800; color: #1e293b; margin-bottom: 16px;">
                📊 Thống Kê Danh Mục Đồ Gia Dụng Trong CSDL MySQL:
            </h4>
            <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 14px;">
                <?php foreach ($categories as $cat): ?>
                    <a href="<?= e(url('products', array('category' => $cat['category_code'] ?? ''))) ?>" style="border: 1px solid #e2e8f0; border-radius: 8px; padding: 16px; background: #f8fafc; text-align: center; text-decoration: none; transition: transform 0.15s, border-color 0.15s;" onmouseover="this.style.borderColor='#d70018'; this.style.transform='translateY(-2px)';" onmouseout="this.style.borderColor='#e2e8f0'; this.style.transform='none';">
                        <h6 style="font-size: 14px; font-weight: 800; color: #1e293b; margin: 0 0 6px 0;"><?= e($cat['category_name']) ?></h6>
                        <span style="background: #fee2e2; color: #d70018; font-size: 12px; font-weight: 800; padding: 4px 10px; border-radius: 20px; display: inline-block;">
                            <?= (int)$cat['total_items'] ?> sản phẩm
                        </span>
                    </a>
                <?php endforeach; ?>
            </div>
        </div>

    </div>
</main>
