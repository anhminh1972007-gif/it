<?php
// pages/products/action.php — chuẩn bị dữ liệu cho trang danh sách sản phẩm
require_once __DIR__ . '/functions.php';

$categoryCode = get_param('category', '');
$brandId = (int)get_param('brand', 0);
$keyword = get_param('q', '');

$title = 'Danh mục thiết bị đồ gia dụng';
if (!empty($keyword)) {
    $title = 'Tìm kiếm: ' . $keyword;
} elseif (!empty($categoryCode)) {
    $title = 'Danh mục: ' . $categoryCode;
}

$products = products_get_all($categoryCode, $brandId, $keyword);
$brandsList = db()->fetchAll("SELECT brand_id, brand_name, country FROM brands ORDER BY brand_name ASC");
$categoriesList = db()->fetchAll("SELECT category_id, category_code, category_name FROM categories ORDER BY category_id ASC");
