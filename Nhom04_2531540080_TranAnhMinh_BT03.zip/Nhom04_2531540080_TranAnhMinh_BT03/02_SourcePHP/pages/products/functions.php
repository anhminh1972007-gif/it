<?php
// pages/products/functions.php — SITE PUBLIC: các hàm truy vấn để KHÁCH xem sản phẩm đồ gia dụng.
// Không viết INSERT / UPDATE / ẨN sản phẩm tại đây.
// Class Database chỉ CHẠY SQL; function quyết định LẤY dữ liệu gì.

function products_get_all($categoryCode = '', $brandId = 0, $keyword = '')
{
    $sql = "SELECT p.product_id, p.product_name, p.price, p.sale_price, p.thumbnail, p.discount_percent, p.warranty_months,
                   c.category_name, c.category_code, b.brand_name, b.brand_id
            FROM products AS p
            JOIN categories AS c ON c.category_id = p.category_id
            JOIN brands AS b ON b.brand_id = p.brand_id
            WHERE p.status = 1";
    $params = array();

    if (!empty($categoryCode)) {
        $sql .= " AND c.category_code = ?";
        $params[] = $categoryCode;
    }
    if ($brandId > 0) {
        $sql .= " AND p.brand_id = ?";
        $params[] = $brandId;
    }
    if (!empty($keyword)) {
        $sql .= " AND (p.product_name LIKE ? OR b.brand_name LIKE ? OR c.category_name LIKE ?)";
        $params[] = "%{$keyword}%";
        $params[] = "%{$keyword}%";
        $params[] = "%{$keyword}%";
    }

    $sql .= " ORDER BY p.product_id DESC";
    return db()->fetchAll($sql, $params);
}

function product_get_by_id($id)
{
    // URL id đến từ client, không ghép $id trực tiếp vào chuỗi SQL (chống SQL Injection)
    $sql = "SELECT p.*, c.category_name, b.brand_name, s.supplier_name
            FROM products AS p
            JOIN categories AS c ON c.category_id = p.category_id
            JOIN brands AS b ON b.brand_id = p.brand_id
            JOIN suppliers AS s ON s.supplier_id = p.supplier_id
            WHERE p.product_id = ? AND p.status = 1";
    return db()->fetchOne($sql, array($id));
}
