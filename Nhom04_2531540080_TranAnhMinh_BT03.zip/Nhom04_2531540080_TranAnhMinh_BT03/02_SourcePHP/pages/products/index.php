<!-- pages/products/index.php — Danh sách sản phẩm đồ gia dụng chuẩn phong cách CellphoneS -->
<main class="catalog-section" style="padding-top: 24px; padding-bottom: 48px;">
    <div class="container">

        <!-- Thanh tiêu đề & bộ lọc danh mục -->
        <div class="catalog-header-bar">
            <div class="catalog-title">
                <span>🔥</span>
                <span><?= !empty($keyword) ? 'Kết Quả Tìm Kiếm: "' . e($keyword) . '"' : 'Toàn Bộ Thiết Bị Đồ Gia Dụng Cao Cấp' ?></span>
                <span style="font-size: 13px; font-weight: 600; color: #64748b;">(<?= count($products) ?> sản phẩm)</span>
            </div>

            <div class="catalog-filter-tabs">
                <a href="<?= e(url('products')) ?>" class="filter-tab <?= (empty($categoryCode) && $brandId == 0 && empty($keyword)) ? 'active' : '' ?>">Tất Cả</a>
                <a href="<?= e(url('products', array('category' => 'KITCHEN'))) ?>" class="filter-tab <?= ($categoryCode === 'KITCHEN') ? 'active' : '' ?>">🍳 Thiết Bị Bếp</a>
                <a href="<?= e(url('products', array('category' => 'CLEANING'))) ?>" class="filter-tab <?= ($categoryCode === 'CLEANING') ? 'active' : '' ?>">🤖 Robot & Hút Bụi</a>
                <a href="<?= e(url('products', array('category' => 'AIR_WATER'))) ?>" class="filter-tab <?= ($categoryCode === 'AIR_WATER') ? 'active' : '' ?>">🍃 Lọc Khí & Nước</a>
                <a href="<?= e(url('products', array('category' => 'UTENSILS'))) ?>" class="filter-tab <?= ($categoryCode === 'UTENSILS') ? 'active' : '' ?>">🥘 Nồi Chảo Inox</a>
                <a href="<?= e(url('products', array('category' => 'SMART_HOME'))) ?>" class="filter-tab <?= ($categoryCode === 'SMART_HOME') ? 'active' : '' ?>">🔐 Khóa & Smart Home</a>
            </div>
        </div>

        <!-- Thanh chọn thương hiệu và thông tin phụ -->
        <div style="background: #fff; border-radius: 8px; border: 1px solid #e5e7eb; padding: 12px 18px; margin-bottom: 20px; display: flex; align-items: center; justify-content: space-between; flex-wrap: wrap; gap: 12px;">
            <div style="display: flex; align-items: center; gap: 10px; flex-wrap: wrap;">
                <span style="font-size: 13px; font-weight: 700; color: #475569;">🏷️ Lọc theo thương hiệu:</span>
                <select onchange="if(this.value) window.location.href=this.value;" style="padding: 7px 14px; border-radius: 6px; border: 1px solid #cbd5e1; font-size: 13px; background: #fff; color: #1e293b; font-weight: 700; cursor: pointer;">
                    <option value="<?= e(url('products', array_filter(array('category' => $categoryCode, 'q' => $keyword)))) ?>">-- Tất cả thương hiệu chính hãng --</option>
                    <?php foreach ($brandsList as $b): 
                        $filterParams = array_filter(array(
                            'category' => $categoryCode,
                            'brand'    => $b['brand_id'],
                            'q'        => $keyword
                        ));
                    ?>
                        <option value="<?= e(url('products', $filterParams)) ?>" <?= ($brandId == $b['brand_id']) ? 'selected' : '' ?>>
                            <?= e($b['brand_name']) ?> (<?= e($b['country'] ?? 'Chính hãng') ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div style="display: flex; gap: 10px; align-items: center;">
                <?php if ($brandId > 0 || !empty($categoryCode) || !empty($keyword)): ?>
                    <a href="<?= e(url('products')) ?>" style="font-size: 12.5px; color: #d70018; font-weight: 700; text-decoration: none; background: #fee2e2; padding: 6px 12px; border-radius: 6px; border: 1px solid #fecdd3;">
                        ✕ Bỏ lọc (Xem tất cả)
                    </a>
                <?php endif; ?>
                <a href="<?= e(admin_url('products')) ?>" style="font-size: 12.5px; color: #1e40af; font-weight: 700; text-decoration: none; background: #eff6ff; padding: 6px 12px; border-radius: 6px; border: 1px solid #bfdbfe;">
                    ⚙️ Xem bảng Admin
                </a>
            </div>
        </div>

        <!-- Danh sách sản phẩm -->
        <?php if (empty($products)): ?>
            <div style="background: #fff; border-radius: 10px; border: 1px solid #e5e7eb; padding: 48px; text-align: center; margin: 20px 0;">
                <div style="font-size: 48px; margin-bottom: 12px;">🔍</div>
                <h3 style="color: #334155; margin-bottom: 8px; font-size: 18px;">Không tìm thấy sản phẩm gia dụng phù hợp!</h3>
                <p style="color: #64748b; font-size: 13.5px; margin-bottom: 18px;">Vui lòng thử tìm kiếm với từ khóa khác hoặc quay lại danh mục đầy đủ.</p>
                <a href="<?= e(url('products')) ?>" style="background: #d70018; color: #fff; font-weight: 700; font-size: 13.5px; padding: 10px 22px; border-radius: 6px; text-decoration: none; display: inline-block;">
                    Xem toàn bộ sản phẩm
                </a>
            </div>
        <?php else: ?>
            <div class="products-grid">
                <?php foreach ($products as $product): ?>
                    <?php require __DIR__ . '/../../layouts/public/product-card.php'; ?>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>

    </div>
</main>
