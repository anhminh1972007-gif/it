<!-- pages/product-detail/index.php — Chi tiết sản phẩm gia dụng phong cách CellphoneS -->
<?php if (!$product): ?>
    <?php require __DIR__ . '/../404/index.php'; ?>
<?php else: 
    $sellingPrice = product_price($product);
    $discountPercent = (int)($product['discount_percent'] ?? 0);
    $price = (float)($product['price'] ?? 0);
    if ($discountPercent == 0 && $price > $sellingPrice && $price > 0) {
        $discountPercent = (int)round((($price - $sellingPrice) / $price) * 100);
    }
    $imagePath = product_image($product['thumbnail']);
?>
<main style="padding: 24px 0 48px 0; background: #f4f6f8;">
    <div class="container">

        <!-- Breadcrumb điều hướng -->
        <div style="font-size: 13px; color: #64748b; margin-bottom: 18px; display: flex; align-items: center; gap: 8px; flex-wrap: wrap;">
            <a href="<?= e(url('home')) ?>" style="color: #64748b; text-decoration: none;">Trang chủ</a>
            <span>›</span>
            <a href="<?= e(url('products')) ?>" style="color: #64748b; text-decoration: none;">Đồ Gia Dụng</a>
            <span>›</span>
            <a href="<?= e(url('products', array('category' => $product['category_code'] ?? ''))) ?>" style="color: #64748b; text-decoration: none;"><?= e($product['category_name']) ?></a>
            <span>›</span>
            <span style="color: #1e293b; font-weight: 700;"><?= e($product['product_name']) ?></span>
        </div>

        <div style="display: grid; grid-template-columns: 460px 1fr; gap: 24px; background: #fff; border-radius: 12px; border: 1px solid #e5e7eb; padding: 28px; box-shadow: 0 2px 8px rgba(0,0,0,0.04);">
            
            <!-- Cột hình ảnh sản phẩm bên trái -->
            <div>
                <div style="background: #ffffff; border: 1px solid #e2e8f0; border-radius: 10px; padding: 20px; text-align: center; position: relative;">
                    <?php if ($discountPercent > 0): ?>
                        <span style="position: absolute; top: 12px; left: 12px; background: #d70018; color: #fff; font-size: 12px; font-weight: 800; padding: 3px 8px; border-radius: 4px;">
                            -<?= $discountPercent ?>%
                        </span>
                    <?php endif; ?>
                    <span style="position: absolute; top: 12px; right: 12px; background: #eff6ff; color: #2563eb; font-size: 11px; font-weight: 700; padding: 3px 8px; border-radius: 4px; border: 1px solid #bfdbfe;">
                        Trả góp 0%
                    </span>
                    <img src="<?= e($imagePath) ?>" alt="<?= e($product['product_name']) ?>" style="max-width: 100%; max-height: 380px; object-fit: contain; margin: 0 auto; display: block;" onerror="this.onerror=null; this.src='assets/images/air_fryer.jpg';">
                </div>

                <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; margin-top: 14px;">
                    <div style="border: 1px solid #e2e8f0; border-radius: 8px; padding: 10px; text-align: center; font-size: 11.5px; color: #475569;">
                        🛡️ <strong>Chính hãng</strong><br>Bảo hành <?= (int)($product['warranty_months'] ?? 12) ?>T
                    </div>
                    <div style="border: 1px solid #e2e8f0; border-radius: 8px; padding: 10px; text-align: center; font-size: 11.5px; color: #475569;">
                        🔄 <strong>Đổi mới</strong><br>1 đổi 1 trong 30N
                    </div>
                    <div style="border: 1px solid #e2e8f0; border-radius: 8px; padding: 10px; text-align: center; font-size: 11.5px; color: #475569;">
                        🚚 <strong>Giao nhanh</strong><br>Miễn phí từ 300K
                    </div>
                </div>
            </div>

            <!-- Cột thông số & giá bán bên phải -->
            <div>
                <div style="display: flex; gap: 8px; margin-bottom: 8px; align-items: center; flex-wrap: wrap;">
                    <span style="background: #fee2e2; color: #d70018; font-size: 11.5px; font-weight: 800; padding: 3px 8px; border-radius: 4px;">
                        <?= e($product['category_name']) ?>
                    </span>
                    <span style="background: #f1f5f9; color: #475569; font-size: 11.5px; font-weight: 700; padding: 3px 8px; border-radius: 4px;">
                        Thương hiệu: <?= e($product['brand_name']) ?>
                    </span>
                    <span style="background: #f8fafc; color: #64748b; font-size: 11.5px; padding: 3px 8px; border-radius: 4px; font-family: monospace;">
                        SKU: <?= e($product['sku']) ?>
                    </span>
                </div>

                <h1 style="font-size: 22px; font-weight: 800; color: #1e293b; line-height: 1.35; margin-bottom: 14px;">
                    <?= e($product['product_name']) ?>
                </h1>

                <!-- Hộp giá ưu đãi nổi bật -->
                <div style="background: #fef2f2; border: 1px solid #fecdd3; border-radius: 10px; padding: 16px 20px; margin-bottom: 20px;">
                    <div style="display: flex; align-items: baseline; gap: 12px; flex-wrap: wrap;">
                        <span style="font-size: 28px; font-weight: 900; color: #d70018;">
                            <?= money($sellingPrice) ?>
                        </span>
                        <?php if (!empty($product['price']) && (float)$product['price'] > $sellingPrice): ?>
                            <span style="font-size: 16px; color: #94a3b8; text-decoration: line-through;">
                                <?= money($product['price']) ?>
                            </span>
                            <span style="background: #d70018; color: #fff; font-size: 12px; font-weight: 800; padding: 2px 8px; border-radius: 4px;">
                                Tiết kiệm <?= money((float)$product['price'] - $sellingPrice) ?>
                            </span>
                        <?php endif; ?>
                    </div>
                    <div style="font-size: 12.5px; color: #166534; font-weight: 700; margin-top: 6px; display: flex; align-items: center; gap: 6px;">
                        <span>✓ Giá đã bao gồm thuế VAT 10% · Miễn phí công lắp đặt nếu có</span>
                    </div>
                </div>

                <!-- Bảng thông số chi tiết từ 4 bảng JOIN -->
                <h4 style="font-size: 15px; font-weight: 800; color: #1e293b; margin-bottom: 10px;">
                    📋 Thông Số Kỹ Thuật (Dữ liệu JOIN 4 bảng CSDL):
                </h4>
                <table style="width: 100%; border-collapse: collapse; font-size: 13px; margin-bottom: 20px; border: 1px solid #e2e8f0; border-radius: 8px; overflow: hidden;">
                    <tbody>
                        <tr style="border-bottom: 1px solid #e2e8f0; background: #f8fafc;">
                            <td style="padding: 10px 14px; font-weight: 700; color: #475569; width: 35%;">Mã sản phẩm (SKU)</td>
                            <td style="padding: 10px 14px; font-family: monospace; font-weight: 700; color: #d70018;"><?= e($product['sku']) ?></td>
                        </tr>
                        <tr style="border-bottom: 1px solid #e2e8f0;">
                            <td style="padding: 10px 14px; font-weight: 700; color: #475569;">Danh mục thiết bị</td>
                            <td style="padding: 10px 14px; color: #1e293b;"><?= e($product['category_name']) ?></td>
                        </tr>
                        <tr style="border-bottom: 1px solid #e2e8f0; background: #f8fafc;">
                            <td style="padding: 10px 14px; font-weight: 700; color: #475569;">Thương hiệu chính hãng</td>
                            <td style="padding: 10px 14px; color: #1e293b; font-weight: 700;"><?= e($product['brand_name']) ?></td>
                        </tr>
                        <tr style="border-bottom: 1px solid #e2e8f0;">
                            <td style="padding: 10px 14px; font-weight: 700; color: #475569;">Nhà phân phối / Cung cấp</td>
                            <td style="padding: 10px 14px; color: #1e293b; font-weight: 700;"><?= e($product['supplier_name']) ?></td>
                        </tr>
                        <tr style="background: #f8fafc;">
                            <td style="padding: 10px 14px; font-weight: 700; color: #475569;">Tình trạng kho hàng</td>
                            <td style="padding: 10px 14px; color: #166534; font-weight: 700;">🟢 Còn hàng (Sẵn sàng giao ngay trong 2 giờ)</td>
                        </tr>
                    </tbody>
                </table>

                <?php if (!empty($product['short_description'])): ?>
                    <div style="background: #f8fafc; border-left: 4px solid #d70018; padding: 12px 16px; border-radius: 4px; font-size: 13px; color: #334155; line-height: 1.6; margin-bottom: 20px;">
                        <strong>Mô tả sản phẩm:</strong><br>
                        <?= nl2br(e($product['short_description'])) ?>
                    </div>
                <?php endif; ?>

                <!-- Nhóm nút hành động -->
                <div style="display: flex; gap: 12px; flex-wrap: wrap;">
                    <a href="<?= e(url('products')) ?>" style="background: #f1f5f9; color: #334155; font-weight: 700; font-size: 13.5px; padding: 12px 20px; border-radius: 8px; text-decoration: none; border: 1px solid #cbd5e1; display: inline-flex; align-items: center; gap: 6px;">
                        ← Quay lại danh mục
                    </a>
                    <a href="<?= e(admin_url('product-edit', array('id' => $product['product_id']))) ?>" style="background: #fee2e2; color: #b91c1c; font-weight: 800; font-size: 13.5px; padding: 12px 20px; border-radius: 8px; text-decoration: none; border: 1px solid #fca5a5; display: inline-flex; align-items: center; gap: 6px;">
                        ⚙️ Quản trị: Sửa sản phẩm này
                    </a>
                </div>

            </div>

        </div>

    </div>
</main>
<?php endif; ?>
