<?php
// pages/product-detail/action.php — nạp thông tin chi tiết của 1 sản phẩm
require_once __DIR__ . '/../products/functions.php';

$id = (int) get_param('id', '0');
$product = product_get_by_id($id);

if (!$product) {
    http_response_code(404);
    $title = 'Không tìm thấy sản phẩm';
    return;
}

$title = $product['product_name'];
