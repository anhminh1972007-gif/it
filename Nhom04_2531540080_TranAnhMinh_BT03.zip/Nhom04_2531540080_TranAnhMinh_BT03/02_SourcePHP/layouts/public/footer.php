<?php
// layouts/public/footer.php — Footer chuẩn giao diện cao cấp CellphoneS (Minh Store)
?>
<footer class="main-footer">
    <div class="container footer-content">

        <!-- Cột 1: Thông tin thương hiệu -->
        <div class="footer-col">
            <div style="display: flex; align-items: center; gap: 8px; margin-bottom: 12px;">
                <div style="background: #d70018; color: #fff; width: 32px; height: 32px; border-radius: 6px; display: flex; align-items: center; justify-content: center; font-weight: 900; font-size: 16px;">M</div>
                <h3 style="color: #0f172a; margin: 0; font-size: 18px; font-weight: 900;">MINH STORE</h3>
            </div>
            <p style="font-size: 13px; color: #64748b; line-height: 1.6; margin-bottom: 12px;">
                Hệ thống phân phối thiết bị gia dụng nhà bếp, robot hút bụi lau nhà, máy lọc nước & không khí chính hãng 100%. Bảo hành tại nhà 24 tháng.
            </p>
            <ul style="font-size: 12.5px; color: #475569; display: flex; flex-direction: column; gap: 6px; padding: 0; list-style: none;">
                <li>📍 Địa chỉ 1: 104 Nguyễn Văn Trỗi, Phường Phú Nhuận, TP.HCM</li>
                <li>📍 Địa chỉ 2: 18A/1 Cộng Hòa, Phường Tân Sơn Nhất, TP.HCM</li>
                <li>📞 Hotline tư vấn: <strong style="color: #d70018;">0338.677.377</strong></li>
                <li>✉️ Email: hotro@minhstore.vn</li>
            </ul>
        </div>

        <!-- Cột 2: Thông tin & hỗ trợ -->
        <div class="footer-col">
            <h4>Thông Tin & Mua Sắm</h4>
            <ul style="padding: 0; list-style: none;">
                <li><a href="<?= e(url('home')) ?>">Trang chủ mua sắm</a></li>
                <li><a href="<?= e(url('products')) ?>">Danh mục thiết bị gia dụng</a></li>
                <li><a href="<?= e(url('products', array('category' => 'KITCHEN'))) ?>">Thiết bị nhà bếp thông minh</a></li>
                <li><a href="<?= e(url('products', array('category' => 'CLEANING'))) ?>">Robot hút bụi & lau nhà</a></li>
                <li><a href="<?= e(url('products', array('category' => 'AIR_WATER'))) ?>">Máy lọc không khí & nước</a></li>
            </ul>
        </div>

        <!-- Cột 3: Minh chứng sinh viên BT03 -->
        <div class="footer-col">
            <h4>Thông Tin Nhóm Thực Hiện</h4>
            <div style="background: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px; font-size: 12.5px; line-height: 1.6;">
                <div style="color: #0f172a; font-weight: 700; margin-bottom: 4px;">👨‍🎓 Trần Anh Minh (Thành viên)</div>
                <div style="color: #475569;">MSSV: <strong>2531540080</strong></div>
                <div style="color: #475569;">Lớp: <strong>010151101405</strong></div>
                <div style="color: #475569;">Đề tài: <strong>04 - Bán Đồ Gia Dụng</strong></div>
                <div style="color: #b91c1c; font-weight: 700; margin-top: 4px;">GVHD: Th.S Lê Mạnh Hùng</div>
            </div>
        </div>

        <!-- Cột 4: Điều hướng kỹ thuật BT03 -->
        <div class="footer-col">
            <h4>Điều Hướng BT03</h4>
            <ul style="padding: 0; list-style: none;">
                <li><a href="<?= e(admin_url('dashboard')) ?>" style="color: #d70018; font-weight: 700;">⚙️ Quản trị Admin (Mô phỏng)</a></li>
                <li><a href="<?= e(admin_url('products')) ?>" style="color: #1e40af; font-weight: 700;">📊 Quản lý sản phẩm (CRUD)</a></li>
                <li><a href="<?= e(admin_url('product-create')) ?>" style="color: #15803d; font-weight: 700;">➕ Thêm sản phẩm mới</a></li>
                <li><a href="<?= e(url('student-public')) ?>" style="color: #854d0e; font-weight: 700;">📋 Báo cáo nhiệm vụ BT03</a></li>
            </ul>
        </div>

    </div>

    <div class="footer-bottom">
        <div class="container">
            &copy; 2026 <strong>Minh Store</strong> - Đề tài 04: Bán Đồ Gia Dụng. Xây dựng bằng <strong>PHP & MySQL (MySQLi Wrapper)</strong> theo chuẩn kiến trúc BT03 của <strong>Th.S Lê Mạnh Hùng</strong> (Học viện Hàng không Việt Nam).
        </div>
    </div>
</footer>

</body>
</html>
