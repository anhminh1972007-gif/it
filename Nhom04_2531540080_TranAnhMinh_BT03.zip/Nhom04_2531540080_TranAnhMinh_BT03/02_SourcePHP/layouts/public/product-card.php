<?php
// layouts/public/product-card.php — thẻ sản phẩm chuẩn giao diện CellphoneS Minh Store
// Dùng trong vòng lặp foreach với biến $product (lấy từ CSDL MySQL qua JOIN)
$sellingPrice = product_price($product);
$discountPercent = (int)($product['discount_percent'] ?? 0);
$price = (float)($product['price'] ?? 0);
if ($discountPercent == 0 && $price > $sellingPrice && $price > 0) {
    $discountPercent = (int)round((($price - $sellingPrice) / $price) * 100);
}
$detailUrl = url('product-detail', array('id' => $product['product_id']));
$imagePath = product_image($product['thumbnail']);
?>
<article class="product-card">
    <div class="card-top">
        <?php if ($discountPercent > 0): ?>
            <span class="discount-badge">-<?= $discountPercent ?>%</span>
        <?php endif; ?>
        <span class="installment-badge">Trả góp 0%</span>

        <a href="<?= e($detailUrl) ?>">
            <img src="<?= e($imagePath) ?>" alt="<?= e($product['product_name']) ?>" class="product-thumb" loading="lazy" onerror="this.onerror=null; this.src='assets/images/air_fryer.jpg';">
        </a>
    </div>

    <div class="card-body">
        <span class="brand-badge"><?= e($product['brand_name'] ?? 'Chính Hãng') ?></span>
        <a href="<?= e($detailUrl) ?>">
            <h3 class="product-title"><?= e($product['product_name']) ?></h3>
        </a>

        <div class="rating-row">
            ★★★★★ <span style="color: #64748b; font-size: 11px;">(BH <?= (int)($product['warranty_months'] ?? 12) ?>T · 1 Đổi 1)</span>
        </div>

        <div class="price-row">
            <span class="current-price"><?= money($sellingPrice) ?></span>
            <?php if (!empty($product['price']) && (float)$product['price'] > $sellingPrice): ?>
                <span class="old-price"><?= money($product['price']) ?></span>
            <?php endif; ?>
        </div>

        <div class="card-actions">
            <a href="<?= e($detailUrl) ?>" class="btn-detail">Xem Chi Tiết</a>
            <a href="<?= e($detailUrl) ?>" class="btn-cart-icon" title="Xem chi tiết & Mua ngay">🛒</a>
        </div>
    </div>
</article>
