<?php
// layouts/public/header.php — Header chuẩn giao diện cao cấp CellphoneS (Minh Store)
// Đảm bảo 100% chuẩn kỹ thuật BT03 của Th.S Lê Mạnh Hùng
$pageTitle = $title ?? 'Minh Store - Thế Giới Đồ Gia Dụng Cao Cấp';
$currentPage = get_param('page', 'home');
?>
<!doctype html>
<html lang="vi">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <base href="<?= (strpos($_SERVER['REQUEST_URI'] ?? '', '/minh-store') === 0 || strpos($_SERVER['SCRIPT_NAME'] ?? '', '/minh-store') === 0) ? '/minh-store/' : '/' ?>">
    <title><?= e($pageTitle) ?> | Minh Store (Đề tài 04 - Nhóm 04)</title>
    <!-- Giao diện gốc chuẩn đỏ/vàng CellphoneS của Minh Store -->
    <link rel="stylesheet" href="<?= e(asset('style.css')) ?>">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
    <style>
        /* Tinh chỉnh bổ sung cho các thành phần điều hướng BT03 */
        .cps-sub-nav {
            background: #ffffff;
            border-bottom: 1px solid #e2e8f0;
            box-shadow: 0 1px 3px rgba(0,0,0,0.04);
        }
        .cps-sub-nav .container {
            display: flex;
            align-items: center;
            justify-content: space-between;
            overflow-x: auto;
            padding-top: 6px;
            padding-bottom: 6px;
            gap: 8px;
        }
        .cps-nav-pill {
            padding: 6px 14px;
            font-size: 13px;
            font-weight: 700;
            border-radius: 6px;
            text-decoration: none;
            color: #334155;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: all 0.2s;
        }
        .cps-nav-pill:hover, .cps-nav-pill.active {
            background: #d70018;
            color: #ffffff !important;
        }
        .admin-link-btn {
            background: #ffffff;
            color: #d70018 !important;
            font-weight: 800;
            border-radius: 8px;
            padding: 6px 14px;
            font-size: 12.5px;
            text-decoration: none;
            box-shadow: 0 2px 6px rgba(0,0,0,0.15);
            display: inline-flex;
            align-items: center;
            gap: 6px;
            transition: transform 0.15s ease, box-shadow 0.15s ease;
        }
        .admin-link-btn:hover {
            transform: translateY(-1px);
            box-shadow: 0 4px 10px rgba(0,0,0,0.25);
            background: #fef2f2;
        }
        .student-header-tag {
            background: rgba(255, 255, 255, 0.15);
            border: 1px solid rgba(255, 255, 255, 0.3);
            border-radius: 8px;
            padding: 4px 10px;
            color: #ffffff;
            font-size: 11.5px;
            display: flex;
            align-items: center;
            gap: 6px;
        }
    </style>
</head>
<body>

<div class="cps-header-wrap">
    <!-- Thanh thông báo trên cùng -->
    <div class="cps-top-strip">
        <div class="container">
            <div>
                <span>✓ Xuất hóa đơn VAT</span>
                <span style="margin: 0 8px; opacity: 0.5;">•</span>
                <span>🚚 Giao nhanh 2H - Miễn phí đơn từ 300K</span>
                <span style="margin: 0 8px; opacity: 0.5;">•</span>
                <span>🛡️ Hàng chính hãng 100% - Bảo hành 24T</span>
            </div>
            <div>
                <span>📍 CS1: 104 Nguyễn Văn Trỗi • CS2: 18A/1 Cộng Hòa, TP.HCM</span>
                <span style="margin: 0 8px; opacity: 0.5;">•</span>
                <span>📞 Hotline: <strong>0338.677.377</strong></span>
            </div>
        </div>
    </div>

    <!-- Header chính màu đỏ Minh Store -->
    <header class="cps-header-main">
        <div class="container cps-header-flex">
            <!-- Logo Minh Store -->
            <a href="<?= e(url('home')) ?>" class="cps-logo" title="Trang chủ Minh Store">
                <div class="cps-logo-badge">M</div>
                <div>MINH STORE</div>
            </a>

            <!-- Nút danh mục -->
            <a href="<?= e(url('products')) ?>" class="cps-btn-cat" title="Xem tất cả danh mục">
                <span>☰</span>
                <span>Danh mục</span>
            </a>

            <!-- Ô tìm kiếm trực tiếp -->
            <div class="cps-search-box">
                <form action="<?= e(base_url('index.php')) ?>" method="GET">
                    <input type="hidden" name="page" value="products">
                    <input type="text" name="q" placeholder="Bạn muốn tìm đồ gia dụng gì? (Nồi chiên, robot hút bụi...)" value="<?= e(get_param('q', '')) ?>" autocomplete="off">
                    <button type="submit" title="Tìm kiếm">🔍</button>
                </form>
            </div>

            <!-- Huy hiệu sinh viên thực hiện -->
            <div class="student-header-tag d-none d-lg-flex" title="Sinh viên thực hiện">
                <span>👨‍🎓</span>
                <span>
                    <strong>Trần Anh Minh</strong> (2531540080)<br>
                    <small style="opacity: 0.9;">Thành viên Nhóm 04 · Đề tài Đồ Gia Dụng</small>
                </span>
            </div>

            <!-- Hotline tư vấn -->
            <a href="tel:0338677377" class="cps-action-btn d-none d-md-flex">
                <span>📞</span>
                <span>0338.677.377</span>
            </a>

            <!-- Nút Quản trị mô phỏng (Yêu cầu liên kết 2 chiều Rubric BT03) -->
            <a href="<?= e(admin_url('dashboard')) ?>" class="admin-link-btn" title="Khu vực quản trị Admin mô phỏng">
                <span>⚙️</span>
                <span>Quản Trị (Mô phỏng)</span>
            </a>
        </div>
    </header>

    <!-- Thanh Menu điều hướng chuẩn BT03 -->
    <nav class="cps-sub-nav">
        <div class="container">
            <div style="display: flex; gap: 6px; align-items: center; white-space: nowrap;">
                <a href="<?= e(url('home')) ?>" class="cps-nav-pill <?= $currentPage === 'home' ? 'active' : '' ?>">
                    🏠 Trang chủ
                </a>
                <a href="<?= e(url('products')) ?>" class="cps-nav-pill <?= $currentPage === 'products' ? 'active' : '' ?>">
                    🍳 Danh mục thiết bị
                </a>
                <a href="<?= e(url('student-public')) ?>" class="cps-nav-pill <?= $currentPage === 'student-public' ? 'active' : '' ?>">
                    📋 Báo cáo BT03 & Sinh viên
                </a>
            </div>

            <div style="display: flex; gap: 8px; align-items: center; white-space: nowrap;">
                <a href="<?= e(admin_url('products')) ?>" style="font-size: 12.5px; font-weight: 700; color: #b91c1c; text-decoration: none; padding: 5px 12px; border-radius: 6px; background: #fee2e2; border: 1px solid #fca5a5; display: inline-flex; align-items: center; gap: 5px;">
                    📊 Quản lý sản phẩm (Admin)
                </a>
                <a href="<?= e(admin_url('product-create')) ?>" style="font-size: 12.5px; font-weight: 700; color: #15803d; text-decoration: none; padding: 5px 12px; border-radius: 6px; background: #dcfce7; border: 1px solid #86efac; display: inline-flex; align-items: center; gap: 5px;">
                    ➕ Thêm SP mới
                </a>
            </div>
        </div>
    </nav>
</div>
