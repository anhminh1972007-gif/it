<?php
/**
 * ==============================================================================
 * ROUTER PUBLIC — MINH STORE (BÀI TẬP 03 - TH.S LÊ MẠNH HÙNG)
 * Nhóm 04: Trần Anh Minh (Thành viên - MSSV: 2531540080)
 * ==============================================================================
 * Chỉ xem dữ liệu, không đặt truy vấn SQL trực tiếp trong Router.
 */

// 1. Phục vụ trực tiếp tài nguyên tĩnh hoặc file PHP riêng biệt nếu chạy qua PHP Built-in Server (php -S)
if (php_sapi_name() === 'cli-server') {
    $path = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    $file = __DIR__ . $path;
    // Bỏ qua tài nguyên tĩnh để PHP Server tự phục vụ (ảnh, CSS, JS)
    if ($path !== '/' && is_file($file) && !preg_match('/\.php$/i', $path)) {
        return false;
    }
    // Nếu gọi trực tiếp file PHP khác (ví dụ /admin/index.php), chuyển quyền thực thi cho file đó
    if ($path !== '/index.php' && $path !== '/' && is_file($file) && preg_match('/\.php$/i', $path)) {
        require $file;
        exit;
    }
}

// 2. Khởi tạo cấu hình và các helper chuẩn của Thầy
require_once __DIR__ . '/config/init.php';

// 3. Nếu người dùng gọi trực tiếp các trang legacy như giỏ hàng / đặt hàng / API chatbot
$uriPath = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH);
if (!isset($_GET['page']) && $uriPath !== '' && $uriPath !== '/' && !preg_match('/(index\.php|\/)$/', $uriPath)) {
    if (file_exists(__DIR__ . '/router/routes.php')) {
        require_once __DIR__ . '/router/routes.php';
        exit;
    }
}

// 4. Bảng định tuyến chuẩn BT03 của Thầy Hùng
$routes = array(
    'home'           => 'home/index.php',
    'products'       => 'products/index.php',
    'product-detail' => 'product-detail/index.php',
    'student-public' => 'student-public/index.php',
);

$page = $_GET['page'] ?? 'home';

if (!is_string($page) || !isset($routes[$page])) {
    http_response_code(404);
    $file = __DIR__ . '/pages/404/index.php';
} else {
    $file = __DIR__ . '/pages/' . $routes[$page];
}

if (!is_file($file)) {
    http_response_code(404);
    $file = __DIR__ . '/pages/404/index.php';
}

// Chạy action.php trước HTML nếu có
$action = dirname($file) . '/action.php';
if (is_file($action)) {
    require $action;
}

// Render layout Public chuẩn
require __DIR__ . '/layouts/public/header.php';
require $file;
require __DIR__ . '/layouts/public/footer.php';
