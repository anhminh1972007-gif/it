@echo off
title MINH STORE - HE THONG BAN DO GIA DUNG THONG MINH
color 0C
cls
echo ===================================================================
echo     CHAO MUNG DEN VOI HE THONG WEBSITE MINH STORE (GIA DUNG)
echo ===================================================================
echo.
echo [1/3] Dang chuyen vao thu muc du an...
cd /d "%~dp0"

echo [2/3] Kiem tra moi truong PHP va MySQL...
where php >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    if exist "%LOCALAPPDATA%\Microsoft\WinGet\Packages\PHP.PHP.8.3_Microsoft.Winget.Source_8wekyb3d8bbwe\php.exe" (
        set "PATH=%LOCALAPPDATA%\Microsoft\WinGet\Packages\PHP.PHP.8.3_Microsoft.Winget.Source_8wekyb3d8bbwe;%PATH%"
    ) else if exist "C:\xampp\php\php.exe" (
        set "PATH=C:\xampp\php;%PATH%"
    )
)

tasklist /fi "imagename eq mysqld.exe" 2>nul | find /i "mysqld.exe" >nul
if %ERRORLEVEL% NEQ 0 (
    if exist "C:\xampp\mysql\bin\mysqld.exe" (
        start "" /b "C:\xampp\mysql\bin\mysqld.exe" --defaults-file="C:\xampp\mysql\bin\my.ini" --standalone
    )
)

echo [3/3] Dang khoi chay PHP Server tai cong 8000...
echo.
echo Dia chi website: http://localhost:8000
echo.
echo [*] Trinh duyet web se tu dong duoc mo sau 2 giay...
echo [*] Nhan Ctrl + C tren cua so nay de dung may chu.
echo ===================================================================
echo.

start "" cmd /c "timeout /t 2 /nobreak >nul && start http://localhost:8000"
php -S localhost:8000 index.php
pause
