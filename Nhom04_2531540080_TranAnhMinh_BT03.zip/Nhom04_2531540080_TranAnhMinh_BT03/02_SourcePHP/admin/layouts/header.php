<?php
// admin/layouts/header.php — Header của AdminLTE
$title = $title ?? 'Khu quản trị';
?>
<!doctype html>
<html lang="vi" data-bs-theme="light" data-lte-color-mode="off">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title><?= e($title) ?> | Minh Store Admin - BT03 (Nhóm 04)</title>
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.13.1/font/bootstrap-icons.min.css">
        <link rel="stylesheet" href="<?= e(asset('admin/vendor/adminlte/css/adminlte.min.css')) ?>">
        <link rel="stylesheet" href="<?= e(asset('admin/css/minishop-admin.css')) ?>">
        <link rel="stylesheet" href="<?= e(asset('admin/css/php2-admin.css')) ?>">
    </head>
    <body class="layout-fixed sidebar-expand-lg bg-body-tertiary">
        <div class="app-wrapper">
            <nav class="app-header navbar navbar-expand bg-body shadow-sm">
                <div class="container-fluid">
                    <ul class="navbar-nav align-items-center">
                        <li class="nav-item">
                            <a class="nav-link" data-lte-toggle="sidebar" href="#" aria-label="Mở menu">☰</a>
                        </li>
                        <li class="nav-item d-none d-sm-block">
                            <span class="nav-link fw-semibold text-danger">
                                <i class="bi bi-shop"></i> Minh Store · Quản Trị Đồ Gia Dụng (Nhóm 04)
                            </span>
                        </li>
                    </ul>
                    <ul class="navbar-nav ms-auto align-items-center gap-2">
                        <li class="nav-item">
                            <a href="<?= e(url('home')) ?>" class="btn btn-sm btn-outline-danger fw-semibold">
                                <i class="bi bi-box-arrow-left"></i> ← Public Mua Sắm
                            </a>
                        </li>
                        <li class="nav-item">
                            <span class="badge text-bg-warning px-2 py-2 fw-semibold">
                                <i class="bi bi-shield-exclamation"></i> DEMO – CHƯA LOGIN
                            </span>
                        </li>
                    </ul>
                </div>
            </nav>
