<?php
// admin/layouts/footer.php — Footer của AdminLTE
?>
        </div>
    </div>
</main>
<footer class="app-footer text-muted small py-3 border-top bg-body">
    <div class="container-fluid d-flex justify-content-between align-items-center flex-wrap gap-2">
        <div>
            <strong>Minh Store Admin</strong> · Bài tập 03: Chuyển đổi sang PHP/MySQL
        </div>
        <div>
            Sinh viên: <strong>Trần Anh Minh</strong> (MSSV: <code>2531540080</code>) · Nhóm 04
        </div>
    </div>
</footer>
</div> <!-- .app-wrapper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= e(asset('admin/vendor/adminlte/js/adminlte.min.js')) ?>"></script>
</body>
</html>
