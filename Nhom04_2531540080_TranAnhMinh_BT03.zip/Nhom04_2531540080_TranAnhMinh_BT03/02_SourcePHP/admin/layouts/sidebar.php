<?php
// admin/layouts/sidebar.php — Sidebar Admin điều hướng các module
$adminPage = get_param('page', 'dashboard');
$nav = array(
    array('dashboard', 'Tổng quan', 'bi bi-speedometer2'),
    array('products', 'Quản lý sản phẩm', 'bi bi-box-seam'),
    array('product-create', 'Thêm sản phẩm mới', 'bi bi-plus-circle'),
    array('student-admin', 'Nhiệm vụ sinh viên (BT03)', 'bi bi-person-check'),
);
?>
<aside class="app-sidebar shadow" data-bs-theme="dark">
    <div class="sidebar-brand">
        <a class="brand-link" href="<?= e(admin_url('dashboard')) ?>">
            <span class="brand-mark bg-danger text-white rounded px-2 py-1 fw-bold">MS</span>
            <span class="brand-text fw-light">
                <strong class="text-white">Minh Store</strong>
                <span class="brand-subtitle d-block small text-warning">ADMIN · BT03 NHÓM 04</span>
            </span>
        </a>
    </div>
    <div class="sidebar-wrapper">
        <nav class="mt-2">
            <ul class="nav sidebar-menu flex-column" data-lte-toggle="treeview" role="menu" data-accordion="false">
                <li class="nav-header">QUẢN TRỊ · MÔ PHỎNG</li>
                <?php foreach ($nav as $item): ?>
                    <li class="nav-item">
                        <a class="nav-link <?= $adminPage === $item[0] ? 'active' : '' ?>" href="<?= e(admin_url($item[0])) ?>">
                            <i class="nav-icon <?= e($item[2]) ?>"></i>
                            <p><?= e($item[1]) ?></p>
                        </a>
                    </li>
                <?php endforeach; ?>

                <li class="nav-header">PHÂN HỆ ERP MỞ RỘNG</li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= e(base_url('admin/stock.php')) ?>">
                        <i class="nav-icon bi bi-boxes"></i>
                        <p>Quản lý tồn kho</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= e(base_url('admin/suppliers.php')) ?>">
                        <i class="nav-icon bi bi-truck"></i>
                        <p>Nhà cung cấp</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?= e(base_url('admin/qr-confirmations.php')) ?>">
                        <i class="nav-icon bi bi-qr-code-scan"></i>
                        <p>Duyệt thanh toán QR</p>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</aside>
<main class="app-main">
    <div class="app-content-header py-3">
        <div class="container-fluid d-flex flex-wrap justify-content-between align-items-center gap-2">
            <h1 class="mb-0 fs-4 page-title text-dark fw-bold"><?= e($title) ?></h1>
            <div class="d-flex gap-2">
                <a class="btn btn-sm btn-outline-secondary" href="<?= e(admin_url('dashboard')) ?>">
                    <i class="bi bi-speedometer2"></i> Dashboard
                </a>
                <a class="btn btn-sm btn-outline-danger" href="<?= e(url('home')) ?>">
                    <i class="bi bi-box-arrow-up-right"></i> Xem Site Khách
                </a>
            </div>
        </div>
    </div>
    <div class="app-content py-2">
        <div class="container-fluid">
