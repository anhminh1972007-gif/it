<?php
// ROUTER ADMIN — MINH STORE (BÀI TẬP 03 - TH.S LÊ MẠNH HÙNG)
// Trang quản trị mô phỏng, KHÔNG CÓ LOGIN / BẮT MẬT KHẨU (theo đúng rubric Thầy Hùng).
// Vẫn dùng chung config/init.php và db() với site Public.

require_once __DIR__ . '/../config/init.php';
require_once __DIR__ . '/includes/security.php';

// Chỉ cho phép trên localhost. Không yêu cầu xác thực tài khoản.
admin_demo_guard();

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

// 1. Danh sách trang được phép truy cập theo chuẩn BT03
$adminRoutes = array(
    'dashboard'       => 'dashboard/index.php',
    'products'        => 'products/index.php',
    'product-create'  => 'product-create/index.php',
    'product-edit'    => 'product-edit/index.php',
    'product-status'  => 'product-status/action.php',  // chỉ POST, không render UI
    'student-admin'   => 'student-admin/index.php',   // phân hệ thực hành sinh viên
);

// 2. Đọc page, nếu sai hoặc không có trong danh sách thì trả về 404
$adminPage = $_GET['page'] ?? 'dashboard';
if (!is_string($adminPage) || !isset($adminRoutes[$adminPage])) {
    http_response_code(404);
    $file = __DIR__ . '/pages/404/index.php';
} else {
    $file = __DIR__ . '/pages/' . $adminRoutes[$adminPage];
}

// 3. Kiểm tra file tồn tại
if (!is_file($file)) {
    http_response_code(404);
    $file = __DIR__ . '/pages/404/index.php';
}

// 4. Tuyến đường chỉ có action.php (Ẩn/Hiện sản phẩm): thực thi một lần qua POST, không render layout
if (basename($file) === 'action.php') {
    if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
        http_response_code(405);
        header('Allow: POST');
        exit('Trang này chỉ chấp nhận phương thức POST.');
    }
    require $file;
    exit;
}

// 5. Chạy action.php trước HTML: thực hiện truy vấn SQL, validate form hoặc redirect
$action = dirname($file) . '/action.php';
if (is_file($action)) {
    require $action;
}

// 6. AdminLTE layout: header + sidebar + nội dung trang + footer
require __DIR__ . '/layouts/header.php';
require __DIR__ . '/layouts/sidebar.php';
require $file;
require __DIR__ . '/layouts/footer.php';
