<?php
// admin/pages/dashboard/functions.php — Dashboard dùng số liệu truy vấn thật từ MySQL.
// KHÔNG dùng số ảo từ template AdminLTE.

function admin_dashboard_stats()
{
    $products = db()->fetchOne("
        SELECT COUNT(*) AS total_products,
               COALESCE(SUM(CASE WHEN status = 1 THEN 1 ELSE 0 END), 0) AS active_products,
               COALESCE(SUM(CASE WHEN status = 0 THEN 1 ELSE 0 END), 0) AS hidden_products
        FROM products
    ");
    $categories = db()->fetchOne('SELECT COUNT(*) AS total_categories FROM categories');
    $brands = db()->fetchOne('SELECT COUNT(*) AS total_brands FROM brands');
    $suppliers = db()->fetchOne('SELECT COUNT(*) AS total_suppliers FROM suppliers');

    return array_merge(
        $products ?? array(),
        $categories ?? array(),
        $brands ?? array(),
        $suppliers ?? array()
    );
}

function admin_dashboard_recent_products()
{
    return db()->fetchAll("
        SELECT p.product_id, p.product_name, p.price, p.sale_price, p.status, c.category_name, b.brand_name
        FROM products AS p
        JOIN categories AS c ON c.category_id = p.category_id
        JOIN brands AS b ON b.brand_id = p.brand_id
        ORDER BY p.product_id DESC 
        LIMIT 5
    ");
}
