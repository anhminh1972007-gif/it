<?php
require_once __DIR__ . '/functions.php';

$title = 'Tổng quan quản trị Minh Store';
$stats = admin_dashboard_stats();
$recentProducts = admin_dashboard_recent_products();
