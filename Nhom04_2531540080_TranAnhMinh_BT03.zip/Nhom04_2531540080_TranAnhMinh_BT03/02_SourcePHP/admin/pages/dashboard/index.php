<!-- admin/pages/dashboard/index.php — Bảng điều khiển KPI đồ gia dụng -->
<div class="row g-3 mb-4">
    <?php
    $cards = array(
        array('Tổng sản phẩm', 'total_products', 'primary', 'bi-boxes'),
        array('Đang mở bán', 'active_products', 'success', 'bi-check-circle-fill'),
        array('Đã tạm ẩn', 'hidden_products', 'secondary', 'bi-eye-slash-fill'),
        array('Danh mục ngành hàng', 'total_categories', 'danger', 'bi-diagram-3-fill'),
    );
    foreach ($cards as $card):
    ?>
        <div class="col-sm-6 col-xl-3">
            <div class="card kpi-card h-100 shadow-sm border-0 border-start border-4 border-<?= e($card[2]) ?>">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center">
                        <div>
                            <div class="kpi-label text-muted small text-uppercase fw-semibold"><?= e($card[0]) ?></div>
                            <div class="kpi-value fs-2 fw-bold text-<?= e($card[2]) ?> mt-1">
                                <?= (int) ($stats[$card[1]] ?? 0) ?>
                            </div>
                        </div>
                        <div class="fs-1 text-<?= e($card[2]) ?> opacity-50">
                            <i class="bi <?= e($card[3]) ?>"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<div class="alert alert-light border shadow-sm mb-4">
    <i class="bi bi-info-circle-fill text-primary"></i> 
    <strong>Ghi chú kiểm tra Rubric BT03:</strong> Các số liệu KPI trên được lấy tự động từ hàm <code>admin_dashboard_stats()</code> qua phương thức <code>db()->fetchOne()</code> từ CSDL MySQL; không phải số liệu gõ cứng (hardcoded) trong giao diện.
</div>

<div class="card shadow-sm border-0">
    <div class="card-header bg-white py-3 d-flex align-items-center justify-content-between">
        <h2 class="card-title fs-5 mb-0 fw-bold text-dark"><i class="bi bi-clock-history"></i> 5 sản phẩm đồ gia dụng mới nhất</h2>
        <a class="btn btn-sm btn-danger fw-semibold" href="<?= e(admin_url('products')) ?>">
            <i class="bi bi-box-seam"></i> Quản lý toàn bộ sản phẩm →
        </a>
    </div>
    <div class="card-body p-0">
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0">
                <thead class="table-light">
                    <tr>
                        <th style="width: 80px;">ID</th>
                        <th>Tên sản phẩm</th>
                        <th>Danh mục</th>
                        <th>Thương hiệu</th>
                        <th>Giá bán thực tế</th>
                        <th>Trạng thái</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($recentProducts as $product): ?>
                        <tr>
                            <td><span class="badge bg-light text-dark border">#<?= (int) $product['product_id'] ?></span></td>
                            <td class="fw-semibold"><?= e($product['product_name']) ?></td>
                            <td><span class="badge bg-secondary"><?= e($product['category_name']) ?></span></td>
                            <td><?= e($product['brand_name']) ?></td>
                            <td class="text-danger fw-bold"><?= money(product_price($product)) ?></td>
                            <td>
                                <?php if ((int) $product['status'] === 1): ?>
                                    <span class="badge bg-success"><i class="bi bi-check2"></i> Đang bán</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary"><i class="bi bi-eye-slash"></i> Đã ẩn</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
