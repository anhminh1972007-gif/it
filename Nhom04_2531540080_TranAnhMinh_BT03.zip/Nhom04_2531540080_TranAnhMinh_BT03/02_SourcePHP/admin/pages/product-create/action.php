<?php
// admin/pages/product-create/action.php — Xử lý thêm sản phẩm mới (PRG pattern)
require_once __DIR__ . '/../products/functions.php';

$title = 'Thêm sản phẩm đồ gia dụng mới';
$errors = array();
$data = admin_product_read_form(array());
$categories = admin_categories_get_all();
$brands = admin_brands_get_all();
$suppliers = admin_suppliers_get_all();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    admin_require_csrf();
    $data = admin_product_read_form($_POST);
    $errors = admin_product_validate($data);
    if (!$errors) {
        admin_product_create($data);
        redirect(admin_url('products')); // Post / Redirect / Get (PRG)
    }
}
