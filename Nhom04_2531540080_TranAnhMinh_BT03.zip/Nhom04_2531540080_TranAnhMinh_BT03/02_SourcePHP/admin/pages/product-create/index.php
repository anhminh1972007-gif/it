<!-- admin/pages/product-create/index.php -->
<?php require __DIR__ . '/../products/form.php'; ?>
