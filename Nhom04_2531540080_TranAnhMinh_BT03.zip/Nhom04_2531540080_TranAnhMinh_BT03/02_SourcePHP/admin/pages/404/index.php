<div class="card p-5 text-center">
    <h1 class="display-4 text-danger fw-bold">404</h1>
    <h4 class="mb-3">Trang quản trị không tồn tại</h4>
    <p class="text-muted">Route bạn yêu cầu không nằm trong danh sách định tuyến cho phép của Admin.</p>
    <div>
        <a href="<?= e(admin_url('dashboard')) ?>" class="btn btn-primary"><i class="bi bi-speedometer2"></i> Về Dashboard</a>
    </div>
</div>
