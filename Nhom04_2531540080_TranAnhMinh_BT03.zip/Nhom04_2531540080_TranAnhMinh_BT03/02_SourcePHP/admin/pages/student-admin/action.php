<?php
// admin/pages/student-admin/action.php — Phân hệ quản trị nhiệm vụ sinh viên BT03
require_once __DIR__ . '/../products/functions.php';

$title = 'Phần thực hành quản trị sinh viên — Trần Anh Minh';
$stats = db()->fetchOne("
    SELECT COUNT(*) AS total,
           COALESCE(SUM(CASE WHEN status = 1 THEN 1 ELSE 0 END), 0) AS active,
           COALESCE(SUM(CASE WHEN status = 0 THEN 1 ELSE 0 END), 0) AS hidden
    FROM products
");
