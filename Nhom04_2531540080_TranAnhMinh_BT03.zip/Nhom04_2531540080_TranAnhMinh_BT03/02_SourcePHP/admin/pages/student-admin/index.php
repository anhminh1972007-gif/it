<!-- admin/pages/student-admin/index.php -->
<div class="card shadow-sm border-0 mb-4">
    <div class="card-header bg-danger text-white py-3">
        <h5 class="card-title mb-0 fw-bold"><i class="bi bi-mortarboard-fill"></i> BÁO CÁO PHÂN CÔNG NHIỆM VỤ QUẢN TRỊ — TRẦN ANH MINH</h5>
    </div>
    <div class="card-body p-4">
        <div class="row g-4">
            <div class="col-md-6">
                <h6 class="fw-bold text-dark border-bottom pb-2">1. Thông tin sinh viên & đề tài</h6>
                <table class="table table-bordered table-sm">
                    <tr><th class="bg-light w-40">Họ và tên</th><td><strong>Trần Anh Minh</strong> (Thành viên nhóm)</td></tr>
                    <tr><th class="bg-light">Mã số SV</th><td><code>2531540080</code></td></tr>
                    <tr><th class="bg-light">Lớp học phần</th><td>010151101405</td></tr>
                    <tr><th class="bg-light">Đề tài</th><td><strong>04 - Website Bán Đồ Gia Dụng (Minh Store)</strong></td></tr>
                    <tr><th class="bg-light">Giảng viên</th><td>Th.S Lê Mạnh Hùng</td></tr>
                </table>
            </div>

            <div class="col-md-6">
                <h6 class="fw-bold text-dark border-bottom pb-2">2. Các tiêu chí kỹ thuật BT03 đã đáp ứng 100%</h6>
                <ul class="list-group list-group-flush small">
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <span><strong>P1:</strong> Router Public (<code>index.php?page=...</code>) & layouts</span>
                        <span class="badge bg-success">Đạt</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <span><strong>P2:</strong> Class <code>Database.php</code> (MySQLi) & hàm <code>db()</code></span>
                        <span class="badge bg-success">Đạt</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <span><strong>P3:</strong> Router Admin (<code>admin/index.php?page=...</code>, No-login)</span>
                        <span class="badge bg-success">Đạt</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <span><strong>P4:</strong> Module Public & Multi-table JOIN (<code>products + categories + brands + suppliers</code>)</span>
                        <span class="badge bg-success">Đạt</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <span><strong>P5 & P6:</strong> Thêm/Sửa sản phẩm, CSRF Token, Post-Redirect-Get</span>
                        <span class="badge bg-success">Đạt</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <span><strong>P7:</strong> Bảng quản lý sản phẩm Admin từ MySQL, Toggle trạng thái Ẩn/Hiện</span>
                        <span class="badge bg-success">Đạt</span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <span><strong>P8:</strong> Nút liên kết 2 chiều Khách ↔ Quản trị & 4 kịch bản T01-T04</span>
                        <span class="badge bg-success">Đạt</span>
                    </li>
                </ul>
            </div>
        </div>

        <div class="mt-4 pt-3 border-top d-flex gap-2">
            <a href="<?= e(admin_url('products')) ?>" class="btn btn-danger btn-sm fw-semibold">
                <i class="bi bi-box-seam"></i> Xem bảng quản lý sản phẩm
            </a>
            <a href="<?= e(admin_url('product-create')) ?>" class="btn btn-outline-danger btn-sm">
                <i class="bi bi-plus-lg"></i> Thêm sản phẩm mới
            </a>
            <a href="<?= e(url('home')) ?>" class="btn btn-outline-secondary btn-sm ms-auto">
                <i class="bi bi-box-arrow-up-right"></i> Mở trang khách hàng
            </a>
        </div>
    </div>
</div>
