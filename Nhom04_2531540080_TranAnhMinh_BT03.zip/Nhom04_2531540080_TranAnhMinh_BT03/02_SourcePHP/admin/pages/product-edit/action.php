<?php
// admin/pages/product-edit/action.php — Xử lý cập nhật sản phẩm đồ gia dụng
require_once __DIR__ . '/../products/functions.php';

$id = filter_var(get_param('id', '0'), FILTER_VALIDATE_INT, array('options' => array('min_range' => 1)));
$id = $id === false ? 0 : $id;
$product = admin_product_get_by_id($id);

if (!$product) {
    http_response_code(404);
    $title = 'Sản phẩm không tồn tại';
    return;
}

$title = 'Sửa thiết bị gia dụng #' . $id;
$errors = array();
$data = $product;
$categories = admin_categories_get_all();
$brands = admin_brands_get_all();
$suppliers = admin_suppliers_get_all();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    admin_require_csrf();
    $data = admin_product_read_form($_POST);
    $errors = admin_product_validate($data, $id);
    if (!$errors) {
        admin_product_update($id, $data);
        redirect(admin_url('products')); // Post / Redirect / Get (PRG)
    }
}
