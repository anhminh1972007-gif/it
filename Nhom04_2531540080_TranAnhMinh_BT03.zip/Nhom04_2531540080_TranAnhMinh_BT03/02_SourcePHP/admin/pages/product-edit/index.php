<!-- admin/pages/product-edit/index.php -->
<?php if (!$product): ?>
    <div class="alert alert-danger shadow-sm">
        <h5 class="fw-bold mb-1"><i class="bi bi-x-circle"></i> Sản phẩm không tồn tại!</h5>
        <p class="mb-2">Không tìm thấy mã sản phẩm hợp lệ trong hệ thống cơ sở dữ liệu.</p>
        <a href="<?= e(admin_url('products')) ?>" class="btn btn-outline-danger btn-sm">Quay lại danh sách</a>
    </div>
<?php else: ?>
    <?php require __DIR__ . '/../products/form.php'; ?>
<?php endif; ?>
