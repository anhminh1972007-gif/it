<?php
// admin/pages/product-status/action.php — Route xử lý thay đổi trạng thái sản phẩm (Ẩn/Hiện)
// Không có giao diện HTML riêng; Router Admin chỉ cho phép gọi qua phương thức POST.

require_once __DIR__ . '/../products/functions.php';

admin_require_csrf();

$id = filter_var($_POST['id'] ?? null, FILTER_VALIDATE_INT, array('options' => array('min_range' => 1)));
$status = $_POST['status'] ?? null;

if ($id === false || $id === null || !is_string($status) || !in_array($status, array('0', '1'), true)) {
    http_response_code(400);
    exit('Mã ID hoặc trạng thái không hợp lệ.');
}

if (!admin_product_get_by_id($id)) {
    http_response_code(404);
    exit('Không tìm thấy sản phẩm cần cập nhật trạng thái.');
}

admin_product_set_status($id, (int) $status);
redirect(admin_url('products'));
