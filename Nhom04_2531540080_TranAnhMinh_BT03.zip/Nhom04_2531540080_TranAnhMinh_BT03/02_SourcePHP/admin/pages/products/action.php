<?php
require_once __DIR__ . '/functions.php';

$title = 'Quản lý sản phẩm đồ gia dụng';
$products = admin_products_get_all(); // Lấy tất cả, không lọc status=1
