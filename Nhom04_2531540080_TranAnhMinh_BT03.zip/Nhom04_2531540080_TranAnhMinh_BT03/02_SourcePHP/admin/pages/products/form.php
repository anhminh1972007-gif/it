<?php
// admin/pages/products/form.php — Dùng chung cho cả trang Thêm và Sửa sản phẩm đồ gia dụng.
// action.php chuẩn bị $data, $errors, và các danh sách categories, brands, suppliers.
?>
<?php if (!empty($errors)): ?>
    <div class="alert alert-danger shadow-sm border-0 mb-4">
        <h6 class="fw-bold mb-2"><i class="bi bi-exclamation-triangle-fill"></i> Vui lòng kiểm tra các lỗi sau:</h6>
        <ul class="mb-0 ps-3">
            <?php foreach ($errors as $error): ?>
                <li><?= e($error) ?></li>
            <?php endforeach; ?>
        </ul>
    </div>
<?php endif; ?>

<div class="card shadow-sm border-0">
    <div class="card-body p-4">
        <form method="post" class="row g-3">
            <input type="hidden" name="csrf_token" value="<?= e(admin_csrf_token()) ?>">

            <div class="col-md-8">
                <label class="form-label fw-semibold">Tên sản phẩm thiết bị gia dụng <span class="text-danger">*</span></label>
                <input class="form-control" name="product_name" maxlength="180" required value="<?= e($data['product_name'] ?? '') ?>" placeholder="Ví dụ: Nồi Chiên Không Dầu Philips XXL 7.2L HD9280">
            </div>

            <div class="col-md-4">
                <label class="form-label fw-semibold">Mã SKU <span class="text-danger">*</span></label>
                <input class="form-control" name="sku" maxlength="50" required value="<?= e($data['sku'] ?? '') ?>" placeholder="Ví dụ: PL-HD9280-XXL">
                <div class="form-text">3–50 ký tự chữ, số hoặc dấu gạch ngang (-).</div>
            </div>

            <div class="col-md-4">
                <label class="form-label fw-semibold">Danh mục ngành hàng <span class="text-danger">*</span></label>
                <select class="form-select" name="category_id" required>
                    <option value="0">-- Chọn danh mục --</option>
                    <?php foreach ($categories as $category): ?>
                        <option value="<?= (int) $category['category_id'] ?>" <?= (int) $category['category_id'] === (int) ($data['category_id'] ?? 0) ? 'selected' : '' ?>>
                            <?= e($category['category_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-4">
                <label class="form-label fw-semibold">Thương hiệu / Hãng <span class="text-danger">*</span></label>
                <select class="form-select" name="brand_id" required>
                    <option value="0">-- Chọn thương hiệu --</option>
                    <?php foreach ($brands as $brand): ?>
                        <option value="<?= (int) $brand['brand_id'] ?>" <?= (int) $brand['brand_id'] === (int) ($data['brand_id'] ?? 0) ? 'selected' : '' ?>>
                            <?= e($brand['brand_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-4">
                <label class="form-label fw-semibold">Nhà cung cấp phân phối <span class="text-danger">*</span></label>
                <select class="form-select" name="supplier_id" required>
                    <option value="0">-- Chọn nhà cung cấp --</option>
                    <?php foreach ($suppliers as $supplier): ?>
                        <option value="<?= (int) $supplier['supplier_id'] ?>" <?= (int) $supplier['supplier_id'] === (int) ($data['supplier_id'] ?? 0) ? 'selected' : '' ?>>
                            <?= e($supplier['supplier_name']) ?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="col-md-6">
                <label class="form-label fw-semibold">Giá gốc niêm yết (VNĐ) <span class="text-danger">*</span></label>
                <div class="input-group">
                    <input class="form-control" type="number" step="1" min="1" name="price" required value="<?= e($data['price'] ?? '') ?>" placeholder="Ví dụ: 3500000">
                    <span class="input-group-text">đ</span>
                </div>
            </div>

            <div class="col-md-6">
                <label class="form-label fw-semibold">Giá khuyến mãi (VNĐ - nếu có)</label>
                <div class="input-group">
                    <input class="form-control" type="number" step="1" min="0" name="sale_price" value="<?= e($data['sale_price'] ?? '') ?>" placeholder="Nhỏ hơn giá gốc (để trống nếu không giảm)">
                    <span class="input-group-text">đ</span>
                </div>
            </div>

            <div class="col-12">
                <label class="form-label fw-semibold">Mô tả tóm tắt thông số kỹ thuật</label>
                <textarea class="form-control" name="short_description" rows="3" placeholder="Ví dụ: Dung tích 7.2L, Công suất 2000W, Công nghệ Rapid Air, Kết nối Wifi HomeID..."><?= e($data['short_description'] ?? '') ?></textarea>
            </div>

            <div class="col-12 pt-3 border-top d-flex gap-2">
                <button type="submit" class="btn btn-danger px-4 fw-semibold">
                    <i class="bi bi-save"></i> Lưu thông tin sản phẩm
                </button>
                <a href="<?= e(admin_url('products')) ?>" class="btn btn-outline-secondary px-4">
                    Hủy bỏ
                </a>
            </div>
        </form>
    </div>
</div>
