<?php
// admin/pages/products/functions.php — SITE ADMIN: nghiệp vụ quản trị sản phẩm đồ gia dụng.
// Chỉ action.php trong /admin mới sử dụng. Không tạo kết nối MySQL thứ hai: luôn gọi db() từ helpers/database.php.

function admin_products_get_all()
{
    $sql = "SELECT p.product_id, p.product_name, p.sku, p.price, p.sale_price,
                   p.thumbnail, p.status, c.category_name, b.brand_name
            FROM products AS p
            JOIN categories AS c ON c.category_id = p.category_id
            JOIN brands AS b ON b.brand_id = p.brand_id
            ORDER BY p.product_id DESC";
    // ADMIN không lọc status=1: cần thấy sản phẩm đã ẩn để khôi phục hoặc bật lại.
    return db()->fetchAll($sql);
}

function admin_product_get_by_id($id)
{
    return db()->fetchOne(
        "SELECT * FROM products WHERE product_id = ?", array($id)
    );
}

function admin_categories_get_all()
{
    return db()->fetchAll("SELECT category_id, category_name FROM categories WHERE status = 1 ORDER BY category_name");
}

function admin_brands_get_all()
{
    return db()->fetchAll("SELECT brand_id, brand_name FROM brands WHERE status = 1 ORDER BY brand_name");
}

function admin_suppliers_get_all()
{
    return db()->fetchAll("SELECT supplier_id, supplier_name FROM suppliers WHERE status = 1 ORDER BY supplier_name");
}

function admin_text_value($post, $key)
{
    $value = $post[$key] ?? '';
    return is_string($value) ? trim($value) : '';
}

function admin_product_read_form($post)
{
    return array(
        'product_name'      => admin_text_value($post, 'product_name'),
        'sku'               => admin_text_value($post, 'sku'),
        'category_id'       => (int) admin_text_value($post, 'category_id'),
        'brand_id'          => (int) admin_text_value($post, 'brand_id'),
        'supplier_id'       => (int) admin_text_value($post, 'supplier_id'),
        'price'             => admin_text_value($post, 'price'),
        'sale_price'        => admin_text_value($post, 'sale_price'),
        'short_description' => admin_text_value($post, 'short_description'),
    );
}

function admin_product_validate($data, $exceptId = 0)
{
    $errors = array();

    if ($data['product_name'] === '') {
        $errors[] = 'Chưa nhập tên sản phẩm.';
    }

    if (!preg_match('/^[A-Za-z0-9-]{3,50}$/', $data['sku'])) {
        $errors[] = 'SKU phải có 3–50 ký tự chữ, số hoặc dấu gạch ngang.';
    } elseif (db()->fetchOne(
        'SELECT product_id FROM products WHERE sku = ? AND product_id <> ?',
        array($data['sku'], $exceptId)
    )) {
        $errors[] = 'SKU đã tồn tại trong hệ thống.';
    }

    if (!is_numeric($data['price']) || (float) $data['price'] <= 0) {
        $errors[] = 'Giá gốc phải là số lớn hơn 0.';
    }

    if ($data['sale_price'] !== '' && (
        !is_numeric($data['sale_price']) || (float) $data['sale_price'] < 0 ||
        (is_numeric($data['price']) && (float) $data['sale_price'] >= (float) $data['price'])
    )) {
        $errors[] = 'Giá khuyến mãi phải nhỏ hơn giá gốc.';
    }

    $validCatIds = array_column(admin_categories_get_all(), 'category_id');
    if (!in_array($data['category_id'], $validCatIds)) {
        $errors[] = 'Vui lòng chọn danh mục hợp lệ.';
    }

    $validBrandIds = array_column(admin_brands_get_all(), 'brand_id');
    if (!in_array($data['brand_id'], $validBrandIds)) {
        $errors[] = 'Vui lòng chọn thương hiệu hợp lệ.';
    }

    $validSupplierIds = array_column(admin_suppliers_get_all(), 'supplier_id');
    if (!in_array($data['supplier_id'], $validSupplierIds)) {
        $errors[] = 'Vui lòng chọn nhà cung cấp hợp lệ.';
    }

    return $errors;
}

function admin_product_make_slug($sku)
{
    return strtolower(preg_replace('/[^a-z0-9-]+/', '-', strtolower($sku)));
}

function admin_product_create($data)
{
    $sql = "INSERT INTO products
                (category_id, brand_id, supplier_id, product_name, slug, sku, price, sale_price, short_description, selling_price, status)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)";
    $price = (float) $data['price'];
    $salePrice = $data['sale_price'] === '' ? null : (float) $data['sale_price'];
    
    db()->execute($sql, array(
        $data['category_id'], $data['brand_id'], $data['supplier_id'],
        $data['product_name'], admin_product_make_slug($data['sku']), $data['sku'],
        $price, $salePrice,
        $data['short_description'],
        $price // đồng bộ cả selling_price cho module cũ
    ));
    return db()->insertId();
}

function admin_product_update($id, $data)
{
    $sql = "UPDATE products
            SET category_id = ?, brand_id = ?, supplier_id = ?, product_name = ?,
                slug = ?, sku = ?, price = ?, sale_price = ?, short_description = ?, selling_price = ?
            WHERE product_id = ?";
    $price = (float) $data['price'];
    $salePrice = $data['sale_price'] === '' ? null : (float) $data['sale_price'];

    return db()->execute($sql, array(
        $data['category_id'], $data['brand_id'], $data['supplier_id'],
        $data['product_name'], admin_product_make_slug($data['sku']), $data['sku'],
        $price, $salePrice,
        $data['short_description'],
        $price,
        $id
    ));
}

function admin_product_set_status($id, $status)
{
    return db()->execute(
        'UPDATE products SET status = ? WHERE product_id = ?', array((int) $status, $id)
    );
}
