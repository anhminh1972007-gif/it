<!-- admin/pages/products/index.php — Bảng quản lý sản phẩm đồ gia dụng -->
<div class="card shadow-sm border-0">
    <div class="card-header bg-white py-3 d-flex justify-content-between align-items-center flex-wrap gap-2">
        <h2 class="card-title fs-5 mb-0 fw-bold text-dark">
            <i class="bi bi-box-seam"></i> Danh sách thiết bị gia dụng (<?= count($products) ?>)
        </h2>
        <a href="<?= e(admin_url('product-create')) ?>" class="btn btn-danger btn-sm fw-semibold">
            <i class="bi bi-plus-lg"></i> + Thêm sản phẩm mới
        </a>
    </div>
    <div class="card-body">
        <div class="alert alert-light border small mb-3">
            <i class="bi bi-info-circle text-primary"></i> 
            <strong>Ghi chú Rubric P7:</strong> Hàm <code>admin_products_get_all()</code> truy vấn toàn bộ bản ghi từ bảng <code>products</code> trong CSDL MySQL (bao gồm cả sản phẩm đang ẩn <code>status = 0</code> để Quản trị viên có thể bật lại).
        </div>
        <div class="table-responsive">
            <table class="table table-hover align-middle mb-0" id="productTable">
                <thead class="table-light">
                    <tr>
                        <th style="width: 70px;">ID</th>
                        <th>Tên sản phẩm</th>
                        <th>SKU</th>
                        <th>Danh mục</th>
                        <th>Giá bán</th>
                        <th>Trạng thái</th>
                        <th class="text-center" style="width: 170px;">Thao tác</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($products as $product): ?>
                        <tr>
                            <td><span class="badge bg-light text-dark border">#<?= (int) $product['product_id'] ?></span></td>
                            <td class="fw-semibold">
                                <?= e($product['product_name']) ?>
                            </td>
                            <td><code><?= e($product['sku']) ?></code></td>
                            <td><span class="badge bg-secondary"><?= e($product['category_name']) ?></span></td>
                            <td class="text-danger fw-bold"><?= money(product_price($product)) ?></td>
                            <td>
                                <?php if ((int) $product['status'] === 1): ?>
                                    <span class="badge bg-success"><i class="bi bi-check-circle"></i> Đang bán</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary"><i class="bi bi-eye-slash"></i> Đã ẩn</span>
                                <?php endif; ?>
                            </td>
                            <td class="text-center text-nowrap">
                                <a class="btn btn-sm btn-outline-primary" href="<?= e(admin_url('product-edit', array('id' => $product['product_id']))) ?>">
                                    <i class="bi bi-pencil"></i> Sửa
                                </a>
                                <form class="d-inline-block ms-1" method="post" action="<?= e(admin_url('product-status')) ?>">
                                    <input type="hidden" name="csrf_token" value="<?= e(admin_csrf_token()) ?>">
                                    <input type="hidden" name="id" value="<?= (int) $product['product_id'] ?>">
                                    <input type="hidden" name="status" value="<?= (int) $product['status'] === 1 ? '0' : '1' ?>">
                                    <button type="submit" class="btn btn-sm <?= (int) $product['status'] === 1 ? 'btn-outline-danger' : 'btn-outline-success' ?>" onclick="return confirm('Xác nhận thay đổi trạng thái sản phẩm #<?= (int) $product['product_id'] ?>?')">
                                        <?= (int) $product['status'] === 1 ? '<i class="bi bi-eye-slash"></i> Ẩn' : '<i class="bi bi-eye"></i> Hiện' ?>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php if (!$products): ?>
            <div class="alert alert-info mt-3 text-center">Chưa có dữ liệu sản phẩm trong CSDL.</div>
        <?php endif; ?>
    </div>
</div>
