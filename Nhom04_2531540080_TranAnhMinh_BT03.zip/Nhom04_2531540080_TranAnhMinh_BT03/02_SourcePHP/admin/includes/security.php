<?php
// admin/includes/security.php — BẢO VỆ TỐI THIỂU CHO DEMO (theo chuẩn của Thầy Lê Mạnh Hùng)
// Không thay thế login / phân quyền đầy đủ; chỉ cho phép trên localhost và dùng CSRF token cho HTTP POST.

function admin_demo_guard()
{
    $remote = $_SERVER['REMOTE_ADDR'] ?? '';
    if (!in_array($remote, array('127.0.0.1', '::1', ''), true)) {
        http_response_code(403);
        exit('Khu Admin minh họa chỉ hoạt động trên localhost. Chưa có đăng nhập.');
    }
}

function admin_csrf_token()
{
    if (!isset($_SESSION['admin_demo_csrf'])) {
        $_SESSION['admin_demo_csrf'] = bin2hex(random_bytes(24));
    }
    return $_SESSION['admin_demo_csrf'];
}

function admin_require_csrf()
{
    $received = $_POST['csrf_token'] ?? null;
    if (!is_string($received) || !hash_equals(admin_csrf_token(), $received)) {
        http_response_code(403);
        exit('CSRF token không hợp lệ. Vui lòng tải lại form.');
    }
}
