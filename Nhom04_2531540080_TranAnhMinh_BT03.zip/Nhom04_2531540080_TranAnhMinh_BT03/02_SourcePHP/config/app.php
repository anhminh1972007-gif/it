<?php
// config/app.php — cấu hình chung của website
return array(
    'name'     => 'Minh Store - Đồ Gia Dụng',
    'base_url' => '/minh-store',
);
