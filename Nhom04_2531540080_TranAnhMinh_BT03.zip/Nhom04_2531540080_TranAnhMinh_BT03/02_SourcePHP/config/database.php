<?php
// config/database.php — cấu hình kết nối CSDL MySQL cho Minh Store

$db_host = '127.0.0.1';
$db_port = 3306;
$db_name = 'minh_store_db';
$db_user = 'root';
$db_pass = '';
$db_charset = 'utf8mb4';

// Khởi tạo $pdo dự phòng cho các module cũ nếu cần
global $pdo;
if (!isset($pdo) || $pdo === null) {
    try {
        $dsn = "mysql:host={$db_host};port={$db_port};dbname={$db_name};charset={$db_charset}";
        $pdo = new PDO($dsn, $db_user, $db_pass, [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => true,
            PDO::ATTR_TIMEOUT            => 1,
        ]);
    } catch (Exception $e) {
        $sqliteFile = file_exists(__DIR__ . '/../database/minh_store.db') ? __DIR__ . '/../database/minh_store.db' : __DIR__ . '/../minh_store.db';
        if (file_exists($sqliteFile)) {
            $pdo = new PDO("sqlite:" . $sqliteFile, null, null, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            ]);
        }
    }
}

if (session_status() === PHP_SESSION_NONE && !headers_sent()) {
    session_start();
}

if (!function_exists('formatVND')) {
    function formatVND($number) {
        return number_format($number, 0, ',', '.') . 'đ';
    }
}

// Bắt buộc return array theo đúng chuẩn kiến trúc của Thầy
return array(
    'host'     => $db_host,
    'port'     => (int) $db_port,
    'database' => $db_name,
    'username' => $db_user,
    'password' => $db_pass,
    'charset'  => $db_charset,
);
